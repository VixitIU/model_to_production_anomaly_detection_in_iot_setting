from flask import Flask, request, jsonify
import joblib
import numpy as np
import os

model_path = os.path.join(os.path.dirname(__file__), "anomaly_model.pkl")
model = joblib.load(model_path)

application = Flask(__name__)

@application.route('/predict', methods=['POST'])
def predict():
    data = request.get_json()

    try:
        features = np.array([
            [
                data['temperature'],
                data['humidity'],
                data['sound_volume']
            ]
        ])

        prediction = model.predict(features)[0]
        score = model.decision_function(features)[0]

        result = {
            "anomaly": int(prediction),
            "anomaly_score": float(score)
        }

        return jsonify(result)

    except Exception as e:
        return jsonify({"error": str(e)}), 400

if __name__ == '__main__':
    port = int(os.environ.get('PORT', 8080))
    application.run(host='0.0.0.0', port=port)